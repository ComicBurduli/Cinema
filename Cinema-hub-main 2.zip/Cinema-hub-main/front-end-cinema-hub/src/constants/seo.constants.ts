export const NO_INDEX_PAGE = { robots: { index: false, follow: false } }

export const SITE_NAME = 'CinemaHub'
export const SITE_DESCRIPTION =
	'Добро пожаловать в CinemaHub - ваш онлайн кинотеатр с широким выбором фильмов на любой вкус. Погрузитесь в мир кино прямо у себя дома, наслаждайтесь новинками и классикой в любое удобное время.'
