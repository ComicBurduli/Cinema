export interface IStatisticItem {
	id: number
	name: string
	value: number
}
