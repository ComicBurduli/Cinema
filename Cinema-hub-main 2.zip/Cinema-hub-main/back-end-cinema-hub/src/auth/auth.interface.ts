export type TypeRole = 'admin' | 'user'
