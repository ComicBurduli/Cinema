export interface FileResponse {
	url: string
	name: string
}
